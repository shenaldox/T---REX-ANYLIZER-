import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

// Initialize ZAI instance
let zaiInstance: any = null

async function getZAIInstance() {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create()
  }
  return zaiInstance
}

// Trading-focused system prompt for SMC analysis
const TRADING_SYSTEM_PROMPT = `You are an expert technical analyst specializing in Smart Money Concepts (SMC) trading. Analyze the provided trading chart image and generate precise trading signals.

Your task is to identify:
1. Market Structure (BOS - Break of Structure, CHoCH - Change of Character)
2. Liquidity Zones (equal highs/lows, obvious stop zones)
3. Order Blocks (OB) - last opposite candle before impulse
4. Fair Value Gaps (FVG) - 3-candle imbalance
5. Optimal Entry, Target, and Stop Loss levels
6. Risk:Reward ratio (only recommend if RR ≥ 1:2)

IMPORTANT RULES:
- Only provide trading signals if the setup has a clear risk:reward of at least 1:2
- If no clear setup exists, return direction as "NEUTRAL"
- Be conservative and realistic in your analysis
- Base your analysis on visible price action and SMC patterns
- Never guarantee profits or predict with 100% certainty

Respond in strict JSON format:
{
  "direction": "BUY" | "SELL" | "NEUTRAL",
  "entry": "exact price level or estimated zone",
  "target": "exact price level or next liquidity zone",
  "stoploss": "exact price level with small buffer",
  "riskReward": "X:Y ratio (e.g., '1:2', '1:3')",
  "confidence": "High/Medium/Low based on setup clarity",
  "reason": "Detailed explanation in bullet points covering:
    - Market structure analysis (BOS/CHoCH)
    - Liquidity identification
    - Order Block or FVG presence
    - Entry zone justification
    - Risk:Reward validation"
}

Example BUY reason:
"BUY confirmed because:
• Market structure bullish (BOS confirmed)
• Sell-side liquidity taken at previous swing high
• Bullish order block identified at support
• Price reacting within FVG zone
• Risk:Reward = 1:3 (favorable setup)"

Example SELL reason:
"SELL confirmed because:
• Market structure bearish (CHoCH to downside)
• Buy-side liquidity taken at previous swing low
• Bearish order block at resistance
• Price rejection from FVG zone
• Risk:Reward = 1:2.5 (acceptable setup)"

NEUTRAL example:
"No clear setup because:
• Price in consolidation range
• No clear market structure break
• Mixed SMC signals
• Insufficient risk:reward potential"`;

export async function POST(request: NextRequest) {
  try {
    const { image } = await request.json()

    if (!image) {
      return NextResponse.json(
        { error: 'Image data is required' },
        { status: 400 }
      )
    }

    // Validate image format
    if (typeof image !== 'string' || !image.startsWith('data:image/')) {
      return NextResponse.json(
        { error: 'Invalid image format. Expected base64 encoded image.' },
        { status: 400 }
      )
    }

    // Get ZAI instance
    const zai = await getZAIInstance()

    // Analyze chart using VLM
    const response = await zai.chat.completions.createVision({
      messages: [
        {
          role: 'user',
          content: [
            {
              type: 'text',
              text: TRADING_SYSTEM_PROMPT
            },
            {
              type: 'image_url',
              image_url: {
                url: image
              }
            }
          ]
        }
      ],
      thinking: { type: 'disabled' }
    })

    const content = response.choices[0]?.message?.content

    if (!content) {
      throw new Error('No response from AI model')
    }

    // Parse JSON response
    let signal
    try {
      // Try to extract JSON from the response (in case there's extra text)
      const jsonMatch = content.match(/\{[\s\S]*\}/)
      const jsonContent = jsonMatch ? jsonMatch[0] : content
      signal = JSON.parse(jsonContent)
    } catch (parseError) {
      // If parsing fails, return the raw content with neutral signal
      signal = {
        direction: 'NEUTRAL',
        entry: 'N/A',
        target: 'N/A',
        stoploss: 'N/A',
        riskReward: 'N/A',
        confidence: 'Low',
        reason: `Unable to parse structured signal. AI response: ${content}`
      }
    }

    // Validate required fields
    if (!signal.direction || !signal.entry || !signal.target || !signal.stoploss || !signal.reason) {
      throw new Error('Invalid signal structure from AI')
    }

    return NextResponse.json({ signal })
  } catch (error) {
    console.error('Chart analysis error:', error)

    return NextResponse.json(
      {
        error: 'Failed to analyze chart',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    )
  }
}
