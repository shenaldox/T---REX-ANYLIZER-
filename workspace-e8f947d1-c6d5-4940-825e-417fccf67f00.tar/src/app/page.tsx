'use client'

import { useState, useCallback } from 'react'
import { Upload, TrendingUp, Target, Shield, Brain, Loader2, X, Download, RefreshCw } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'

interface TradingSignal {
  direction: 'BUY' | 'SELL' | 'NEUTRAL'
  entry: string
  target: string
  stoploss: string
  riskReward: string
  confidence: string
  reason: string
}

export default function Home() {
  const [uploadedImage, setUploadedImage] = useState<string | null>(null)
  const [analyzing, setAnalyzing] = useState(false)
  const [signal, setSignal] = useState<TradingSignal | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [dragActive, setDragActive] = useState(false)

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true)
    } else if (e.type === 'dragleave') {
      setDragActive(false)
    }
  }, [])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0])
    }
  }, [])

  const handleFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      setError('Please upload an image file (PNG, JPG, etc.)')
      return
    }

    if (file.size > 10 * 1024 * 1024) {
      setError('File size must be less than 10MB')
      return
    }

    setError(null)
    setSignal(null)

    const reader = new FileReader()
    reader.onload = (e) => {
      setUploadedImage(e.target?.result as string)
    }
    reader.readAsDataURL(file)
  }

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0])
    }
  }

  const analyzeChart = async () => {
    if (!uploadedImage) return

    setAnalyzing(true)
    setError(null)
    setSignal(null)

    try {
      const response = await fetch('/api/analyze-chart', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ image: uploadedImage }),
      })

      if (!response.ok) {
        throw new Error('Failed to analyze chart')
      }

      const data = await response.json()
      setSignal(data.signal)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred during analysis')
    } finally {
      setAnalyzing(false)
    }
  }

  const reset = () => {
    setUploadedImage(null)
    setSignal(null)
    setError(null)
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      {/* Header */}
      <header className="border-b bg-white/50 dark:bg-slate-950/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-slate-900 dark:text-slate-50">
                  AI Chart Analyzer
                </h1>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  Smart Money Concepts Trading Signals
                </p>
              </div>
            </div>
            <Badge variant="outline" className="gap-1">
              <TrendingUp className="w-3 h-3" />
              Powered by AI
            </Badge>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Hero Section */}
        <div className="text-center mb-8">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-slate-50 mb-3">
            Transform Charts into Trading Signals
          </h2>
          <p className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
            Upload your trading chart screenshots and get AI-powered analysis with entry points,
            targets, stop loss, and Smart Money Concepts explanations.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Upload Section */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="w-5 h-5" />
                Upload Chart Image
              </CardTitle>
              <CardDescription>
                Upload a TradingView or chart screenshot for AI analysis
              </CardDescription>
            </CardHeader>
            <CardContent>
              {!uploadedImage ? (
                <div
                  className={`relative border-2 border-dashed rounded-lg p-8 text-center transition-all ${
                    dragActive
                      ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/20'
                      : 'border-slate-300 dark:border-slate-700 hover:border-slate-400'
                  }`}
                  onDragEnter={handleDrag}
                  onDragLeave={handleDrag}
                  onDragOver={handleDrag}
                  onDrop={handleDrop}
                >
                  <input
                    type="file"
                    id="file-upload"
                    className="hidden"
                    accept="image/*"
                    onChange={handleFileInput}
                  />
                  <div className="flex flex-col items-center gap-4">
                    <div className="w-16 h-16 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center">
                      <Upload className="w-8 h-8 text-slate-400" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-slate-900 dark:text-slate-50 mb-1">
                        Drop your chart image here
                      </p>
                      <p className="text-xs text-slate-600 dark:text-slate-400 mb-3">
                        PNG, JPG up to 10MB
                      </p>
                      <Button asChild>
                        <label htmlFor="file-upload" className="cursor-pointer">
                          Browse Files
                        </label>
                      </Button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="relative rounded-lg overflow-hidden border bg-slate-900">
                    <img
                      src={uploadedImage}
                      alt="Uploaded chart"
                      className="w-full h-auto max-h-96 object-contain"
                    />
                    <Button
                      size="icon"
                      variant="destructive"
                      className="absolute top-2 right-2"
                      onClick={reset}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                  <Button
                    onClick={analyzeChart}
                    disabled={analyzing}
                    className="w-full"
                    size="lg"
                  >
                    {analyzing ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Analyzing Chart...
                      </>
                    ) : (
                      <>
                        <TrendingUp className="w-4 h-4 mr-2" />
                        Generate Trading Signals
                      </>
                    )}
                  </Button>
                </div>
              )}

              {error && (
                <Alert variant="destructive" className="mt-4">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>

          {/* Results Section */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5" />
                Trading Signals
              </CardTitle>
              <CardDescription>
                AI-generated trading recommendations based on Smart Money Concepts
              </CardDescription>
            </CardHeader>
            <CardContent>
              {!signal ? (
                <div className="flex flex-col items-center justify-center h-80 text-center gap-4">
                  <div className="w-20 h-20 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center">
                    <TrendingUp className="w-10 h-10 text-slate-300 dark:text-slate-600" />
                  </div>
                  <div>
                    <p className="font-medium text-slate-900 dark:text-slate-50 mb-1">
                      No signals yet
                    </p>
                    <p className="text-sm text-slate-600 dark:text-slate-400">
                      Upload a chart image to generate trading signals
                    </p>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Direction Badge */}
                  <div className="text-center py-4">
                    <Badge
                      className={`text-lg px-6 py-2 ${
                        signal.direction === 'BUY'
                          ? 'bg-emerald-500 hover:bg-emerald-600'
                          : signal.direction === 'SELL'
                            ? 'bg-red-500 hover:bg-red-600'
                            : 'bg-slate-500 hover:bg-slate-600'
                      }`}
                    >
                      {signal.direction}
                    </Badge>
                  </div>

                  {/* Signal Cards */}
                  <div className="grid grid-cols-3 gap-3">
                    <div className="bg-slate-50 dark:bg-slate-800 rounded-lg p-4 text-center">
                      <p className="text-xs text-slate-600 dark:text-slate-400 mb-1">Entry</p>
                      <p className="text-lg font-semibold text-slate-900 dark:text-slate-50">
                        {signal.entry}
                      </p>
                    </div>
                    <div className="bg-slate-50 dark:bg-slate-800 rounded-lg p-4 text-center">
                      <p className="text-xs text-slate-600 dark:text-slate-400 mb-1">Target</p>
                      <p className="text-lg font-semibold text-emerald-600 dark:text-emerald-400">
                        {signal.target}
                      </p>
                    </div>
                    <div className="bg-slate-50 dark:bg-slate-800 rounded-lg p-4 text-center">
                      <p className="text-xs text-slate-600 dark:text-slate-400 mb-1">Stop Loss</p>
                      <p className="text-lg font-semibold text-red-600 dark:text-red-400">
                        {signal.stoploss}
                      </p>
                    </div>
                  </div>

                  {/* Risk Reward */}
                  <div className="bg-gradient-to-r from-slate-50 to-slate-100 dark:from-slate-800 dark:to-slate-700 rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Shield className="w-5 h-5 text-slate-600 dark:text-slate-400" />
                        <span className="text-sm text-slate-600 dark:text-slate-400">Risk:Reward</span>
                      </div>
                      <Badge variant="outline">{signal.riskReward}</Badge>
                    </div>
                  </div>

                  {/* Confidence */}
                  <div className="bg-gradient-to-r from-slate-50 to-slate-100 dark:from-slate-800 dark:to-slate-700 rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Brain className="w-5 h-5 text-slate-600 dark:text-slate-400" />
                        <span className="text-sm text-slate-600 dark:text-slate-400">AI Confidence</span>
                      </div>
                      <Badge variant="outline">{signal.confidence}</Badge>
                    </div>
                  </div>

                  {/* Reason */}
                  <div className="bg-slate-50 dark:bg-slate-800 rounded-lg p-4">
                    <h4 className="text-sm font-semibold text-slate-900 dark:text-slate-50 mb-2">
                      Analysis Reasoning
                    </h4>
                    <p className="text-sm text-slate-600 dark:text-slate-400 whitespace-pre-wrap">
                      {signal.reason}
                    </p>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      onClick={reset}
                      className="flex-1"
                    >
                      <RefreshCw className="w-4 h-4 mr-2" />
                      Analyze Another
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Info Cards */}
        <div className="grid md:grid-cols-3 gap-4 mt-8">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Market Structure</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-slate-600 dark:text-slate-400">
                Detects BOS (Break of Structure) and CHoCH (Change of Character) patterns
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Liquidity Zones</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-slate-600 dark:text-slate-400">
                Identifies equal highs/lows and key stop loss levels
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Order Blocks & FVG</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-slate-600 dark:text-slate-400">
                Detects Order Blocks and Fair Value Gaps for optimal entries
              </p>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t bg-white/50 dark:bg-slate-950/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-6">
          <div className="text-center text-sm text-slate-600 dark:text-slate-400">
            <p className="mb-2">
              ⚠️ <strong>Disclaimer:</strong> This tool provides AI-generated analysis for educational purposes only.
              Not financial advice. Always do your own research before trading.
            </p>
            <p className="text-xs">
              Built with AI Vision & Smart Money Concepts
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
